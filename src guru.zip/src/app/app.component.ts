import { Component } from '@angular/core';
import { Platform, LoadingController, AlertController } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { OrderGuruPage } from '../pages/order-guru/order-guru';
import { LoginPage } from '../pages/login/login';
import { HomePage } from '../pages/home/home';
import * as firebase from 'firebase';
import * as moment from 'moment';
import { Push, PushObject, PushOptions } from '@ionic-native/push';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { Calendar } from '@ionic-native/calendar';




@Component({
  template: `<ion-nav [root]="rootPage"></ion-nav>`
})
export class MyApp {
  public rootPage: any;

  constructor(public calendar:Calendar,platform: Platform, LoadingController:LoadingController, public push:Push, public alertCtrl:AlertController,public localNotif:LocalNotifications) {
    Splashscreen.show();
  var config = {
    apiKey: "AIzaSyBFKhA17tr8f2ki0agybmDZ2Pk_iYu2YLg",
    authDomain: "web-uat-1a4d8.firebaseapp.com",
    databaseURL: "https://web-uat-1a4d8.firebaseio.com",
    projectId: "web-uat-1a4d8",
    storageBucket: "web-uat-1a4d8.appspot.com",
    messagingSenderId: "732818088048"
};
    firebase.initializeApp(config);
    firebase.auth().onAuthStateChanged((user) =>  {
    if(user){
      let loader = LoadingController.create({
        content:'<img src="./assets/loading.gif"/>',
        spinner:'hide'});
      loader.present();
      setTimeout(()=>{
        this.pushSetup(user.uid);
        this.rootPage=HomePage;
        loader.dismissAll();
      },2000);
    }else{
      this.rootPage=LoginPage;
      }
    });

  platform.ready().then(() => {

       StatusBar.styleDefault();
       setTimeout(()=> {
         Splashscreen.hide();
       }, 2000);

     });

   }

   pushSetup(uid){
     const options:PushOptions = {
       android:{
         senderID: '732818088048',
         forceShow:true,
         sound:true
       },
       ios:{
         alert:'true',
         badge: true,
         sound: 'false'
       },
       windows:{}
     };
     const pushObject:PushObject = this.push.init(options);
     pushObject.on('notification').subscribe((notification:any) => {
      //  console.log('Your notification',notification);
        // if(notification.additionalData.foreground){
        //   let myAlert = this.alertCtrl.create({
        //     title:notification.title,
        //     message: notification.message,
        //     buttons: [
        //               {
        //                 text: 'OK',
        //                 handler: () => {
        //                   return true;
        //                 }
        //               }
        //             ]
        //   })
          if(notification.additionalData.startDate != undefined){
              this.localNotif.schedule({
               text: 'Anda memiliki jadwal mengajar pada '+moment(notification.additionalData.startDate).format('LLLL'),
               at: new Date(moment(notification.additionalData.startDate).subtract(1,'day').format('YYYY-MM-DD')),
               led: 'FF0000'
              });
              this.calendar.createEvent(notification.additionalData.title,'' ,notification.additionalData.message , new Date(notification.additionalData.startDate), new Date(notification.additionalData.endDate))
              // myAlert.present();
            }

     })
     pushObject.on('registration').subscribe((registration:any) => {firebase.database().ref('users/'+uid).update({deviceId:registration.registrationId})});
     pushObject.on('error').subscribe(error => console.log('plugin error',error));

   }
  }
