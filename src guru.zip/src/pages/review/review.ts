import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { UserService  } from '../../providers/user-service';
import * as _ from 'lodash';

/*
  Generated class for the Review page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-review',
  templateUrl: 'review.html',
  providers: [UserService]
})
export class ReviewPage {
  public timeLine:any;
  public segmentPage:any;
  public rate:any=0;
  public uid:any;
  public user:any=[];
  public data:any=[];
  public profile:any=[];
  public review:any=[];
  constructor(public navCtrl: NavController, public navParams: NavParams,  public userService: UserService) {
    this.uid=this.navParams.get('uid');
    this.profile = this.navParams.get('dataUser');
    this.getData();
    this.getReview();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReviewPage');
  }
  getReview(){
    var that = this;
    this.userService.getTutorReview(this.uid).subscribe(sabi=>{
      if(sabi.length > 0){
        this.review = sabi;
        sabi.forEach(e=>{
          that.rate = that.rate + e.rate;
        })
        that.rate = Math.ceil(that.rate / that.review.length);
      }
    })
  }
  getData(){
    var that = this;
    this.userService.tutorCariMurid(this.uid).subscribe(snapshot =>{
      var data = snapshot
      var order:any = [];
      var today = new Date();
      var month = today.getMonth();
      var year = today.getFullYear();
      order.monthly = [];
      order.yearly = [];
      this.user.session = [];
      this.user.revenue = [];
      this.user.order = [];
      this.user.session.cum=0;
      this.user.revenue.cum=0;
      this.user.order.cum=0;
      this.user.session.monthly=0;
      this.user.revenue.monthly=0;
      this.user.order.monthly=0;
      this.user.session.yearly=0;
      this.user.revenue.yearly=0;
      this.user.order.yearly=0;
      if(snapshot.length >0){
        that.user.order.cum = data.length;
        snapshot.forEach(e=>{
          var date = new Date(e.orderSchedule.startDate);
          if(e.status == 'finish'){


          if(date.getMonth() == month ){
            order.monthly.push(e);
          }
          if(date.getFullYear() == year){
            order.yearly.push(e);
          }
          that.user.revenue.cum = that.user.revenue.cum + e.totalHarga;
          // that.review.push({review:e.review,date:e.orderSchedule.endDate});
          // that.rate= that.rate + e.rate;
          that.user.session.cum = that.user.session.cum + e.sessions.length;
          }
        })
        that.user.order.monthly=order.monthly.length;
        that.user.order.yearly = order.yearly.length;
        that.user.revenue.monthly = _.sumBy(order.monthly, 'totalHarga');
        that.user.revenue.yearly = _.sumBy(order.yearly, 'totalHarga');
        that.user.session.monthly = _.sumBy(order.monthly, 'sessions.length');
        that.user.session.yearly = _.sumBy(order.yearly, 'sessions.length');
        // that.rate = Math.ceil(that.rate / that.review.length);
        // console.log(that.rate);
        // console.log(that.review);
      }
      console.log(this.user);
    })
  }
  // getData(){
  //   var that=this;
  //   this.userService.viewTutorProfile(this.uid).once('value',function(snapshot){
  //     that.user=snapshot.val();
  //   }).then((getTotal)=>{
  //     that.user.session.cum=0;
  //     that.user.revenue.cum=0;
  //     that.user.order.cum=0;
  //     that.user.session.monthly=0;
  //     that.user.revenue.monthly=0;
  //     that.user.order.monthly=0;
  //     that.user.session.yearly=0;
  //     that.user.revenue.yearly=0;
  //     that.user.order.yearly=0;
  //     that.userService.getBooking(that.uid).on('value',function(snapshot){
  //       snapshot.forEach(function(fuck){
  //         var dats = fuck.val();
  //         dats.month = new Date(dats.orderSchedule.startDate).getMonth();
  //         dats.year = new Date(dats.orderSchedule.startDate).getFullYear();
  //         dats.totalSession = dats.session.length;
  //         that.user.session.cum=that.user.session.cum+dats.session.length
  //         that.user.revenue.cum=that.user.revenue.cum+dats.totalHarga;
  //         that.data.push(dats);
  //       })
  //     that.userService.getBooking(that.uid).on('value',function(snapshot){
  //       snapshot.forEach(function(fuck){
  //         var dats = fuck.val();
  //         dats.month = new Date(dats.orderSchedule.startDate).getMonth();
  //         dats.year = new Date(dats.orderSchedule.startDate).getFullYear();
  //         dats.totalSession = dats.session.length;
  //         that.user.session.cum=that.user.session.cum+dats.session.length
  //         that.user.revenue.cum=that.user.revenue.cum+dats.totalHarga;
  //         that.data.push(dats);
  //       })
  //     }).then((review)=>{
  //       that.userService.getReview(that.uid).on('value',function(snapshot){
  //         snapshot.forEach(function(review){
  //           var datsky = review.val();
  //           that.review.push(datsky);
  //         })
  //       });
  //       var date=new Date();
  //       var month = date.getMonth();
  //       var year = date.getFullYear();
  //       that.user.order.monthly=_.filter(that.data, {month:month}).length;
  //       that.user.order.yearly=_.filter(that.data, {year:year}).length;
  //       that.user.order.cum=that.data.length;
  //       that.user.session.monthly=_.filter(that.data, {month:month});
  //       that.user.session.yearly=_.filter(that.data, {year:year});
  //       })
  //     })
  //   })
  // }
}
