import { Component,ViewChild } from '@angular/core';
import { NavController, NavParams, AlertController,ActionSheetController,ToastController, Platform, Content, LoadingController, Loading } from 'ionic-angular';
import { Zapier  } from '../../providers/zapier';
import { UserService  } from '../../providers/user-service';
import { FilePath } from '@ionic-native/file-path';
import { FileOpener } from '@ionic-native/file-opener';
import { FileChooser } from '@ionic-native/file-chooser';
import { Transfer, FileUploadOptions, TransferObject } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/Camera';
import * as firebase from 'firebase';
import { IonicImageViewerModule } from 'ionic-img-viewer';
import * as _ from 'lodash';
import * as moment from 'moment';

/*
  Generated class for the Konsultasi page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
declare var cordova: any
declare var window;
@Component({
  selector: 'page-konsultasi',
  templateUrl: 'konsultasi.html',
  providers:  [UserService,Zapier]
})
export class KonsultasiPage {
  @ViewChild(Content) content: Content;
  public theChat:any;
  public Tutor:any;
  public receiver:any;
  public uid:any;
  public deviceId:any;
  public muridUid:any;
  public name:any;
  public loading: Loading;
  public status:any=false;
  public chatData:any=[];
  public offset:any;
  public muridData:any=[];

  constructor(private zapier:Zapier,private Camera:Camera, private File:File, private FilePath:FilePath, private FileChooser:FileChooser, public platform: Platform, public loadingCtrl: LoadingController,
     public actionSheetCtrl: ActionSheetController, public toastCtrl: ToastController,public navCtrl: NavController, public alertCtrl: AlertController,public userService: UserService, public params:NavParams) {
  console.log(this.params);
  this.uid = this.params.data.data;
  if(this.params.get('muridUid') != undefined){
    this.status = true;
    this.muridUid = this.params.get('muridUid');
    this.muridData = this.params.get('muridData')
    this.name = this.params.get('muridName');
    this.deviceId = this.muridData.deviceId;
  }
  if(this.muridUid == undefined){
      this.noMurid(this.uid);
  }else{
    this.chatHim(this.muridUid,this.name)
  }



  // this.tutor
  // this.userService.myChatsGuru(this.uid,'cs').once('value').then(function(snapshot){
  //   var data=[];
  //   snapshot.forEach(function(childData){
  //     console.log(childData);
  //     var dats = childData.val();
  //     dats['key']=childData.key;
  //     that.chatData.push(dats);
  //   });
  //   console.log(that.chatData);
  //   return that.chatData.push(data);
  // });
  // console.log(this.chatData);
}

  dismiss(){
    this.offset.unsubscribe();
    this.navCtrl.pop();
  }
noMurid(tutorId){
  var that= this;
  this.userService.tutorCariMurid(tutorId).subscribe(snapshot =>{
    that.muridData=[];
    console.log(snapshot);
    if(snapshot.length == 0){
        this.presentAlert('anda belum mempunyai jadwal mengajar');
    }
    var data = snapshot;
    this.muridData = _.remove(data, {status:'booked'});
    // snapshot.forEach(e=>{
    //   that.tutorData.push(e);
    // })
  })
}
chatHim(muridUid,muridName){
  this.status = true;
  var that = this;
  this.muridUid = muridUid;
  this.name = muridName;
  this.offset=this.userService.newChatTutor(muridUid,this.uid).subscribe(snaps=>{
    that.chatData=[];
    var count =0;
    if(snaps.length == 0){
      that.userService.firstChatTutor(this.muridUid,this.uid);
    }
    console.log(snaps);
      this.chatData=snaps;

      snaps.forEach(e=>{
        if(e.position == 'right' && e.status == false){
          count=count+1;
          that.userService.updateChatStatusTutor(that.muridUid,that.uid,e.$key);
        }
      })

      if(count !=0){
        that.presentToast('Ada chat dari CS');
        return that.scrollToBottom();
      }
  })
}
  openThis(name:string){
    if(name == 'back'){
      this.navCtrl.pop();
      }
    }
  sendChat(){
    var that= this;
    this.userService.sendChatTutorNew(this.theChat,this.muridUid,this.uid,'text').then(()=>{
      console.log(this.theChat);
      let notifChat = { title: 'New chat from '+that.muridData.tutorName, message :that.theChat, to:that.deviceId};
      that.zapier.sendNotification(notifChat).subscribe(mintaReview =>{
        return that.theChat= null;
      })

    });
  }
  scrollToBottom() {
       setTimeout(() => {
           this.content.scrollToBottom(300);
       });
   }
  getDates(dates){
   return moment(dates).format('DD/MM/YYYY');
  }
  getHour(hour){
    var a = new Date(hour).getHours();
    var b = new Date(hour).getMinutes();
    if(b > 9){
      return a+':'+b;
    }else{
      return a+':0'+b;
    }
  }

  presentAlert(message) {
    let alert = this.alertCtrl.create({
      title: 'Sorry',
      message: message,
      buttons: [{text:'Dismiss',handler: datas=>{
        this.navCtrl.pop();
      }}]
    });

    alert.present();
  }
  private createFileName() {
  var d = new Date(),
  n = d.getTime(),
  newFileName =  n + ".jpg";
  return newFileName;
}

  public uploadImage(data) {
    var that =this;
  // Destination URL
  let storageRef = firebase.storage().ref(this.uid+'/'+this.muridUid);

  const filename = new Date().getTime();
  const imageRef = storageRef.child(`${filename}.png`);

  this.loading = this.loadingCtrl.create({
  });
  this.loading.present();
    imageRef.putString(data, 'base64', {contentType:'image/jpg'}).then((snapshot)=> {
        that.userService.sendChatTutorNew(snapshot.downloadURL,this.muridUid,this.uid,'img');
      this.loading.dismissAll()
    }, err => {
      this.loading.dismissAll()
    });

}


private presentToast(text) {
  let toast = this.toastCtrl.create({
    message: text,
    duration: 3000,
    position: 'top'
  });
  toast.present();
}

// Always get the accurate path to your apps folder
public pathForImage(img) {
  if (img === null) {
    return '';
  } else {
    return cordova.file.dataDirectory + img;
  }
}
  public takePicture(sourceType) {
    // Create options for the Camera Dialog
    const options : CameraOptions = {
      quality: 50,
      sourceType: sourceType,
      saveToPhotoAlbum: true,
      allowEdit : true,
      targetWidth : 600,
      targetHeight : 600,
      destinationType: 0,
      encodingType: this.Camera.EncodingType.JPEG,
      mediaType: 0,
      correctOrientation : true
    };

    // Get the data of an image
    this.Camera.getPicture(options).then((imagePath) => {
      // Special handling for Android library
            this.uploadImage(imagePath);
    }, (err) => {
    });
  }

   public presentActionSheet() {
     let actionSheet = this.actionSheetCtrl.create({
       title: 'Select Image Source',
       buttons: [
         {
           text: 'Load from Library',
           handler: () => {
             this.takePicture(0);
           }
         },
         {
           text: 'Use Camera',
           handler: () => {
             this.takePicture(1);
           }
         },
         {
           text: 'Cancel',
           role: 'cancel'
         }
       ]
     });
     actionSheet.present();
   }
}
