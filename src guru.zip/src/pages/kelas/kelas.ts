import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController,ToastController } from 'ionic-angular';
import { ListCat  } from '../../providers/list-cat';
import { UserService  } from '../../providers/user-service';
import * as _ from 'lodash';
import * as firebase from 'firebase';
import { TextMaskModule } from 'angular2-text-mask';
import createNumberMask from 'text-mask-addons/dist/createNumberMask';

/*
  Generated class for the Kelas page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-kelas',
  templateUrl: 'kelas.html',
  providers:[ListCat,UserService]
})
export class KelasPage {
  public uid:any;
  public sendData:any=[];
  public sendDataUmum:any=[];
  public categoryData:any=[];
  public umum:any=[];
  public stateVerification:any;
  // data: Array<{name: string, details: string, icon: string, showDetails: boolean}> = [];
  public data:any=[];
  public userProduct:any=[];
  public mask = createNumberMask({
    includeThousandsSeparator : true,
    prefix:'',
    thousandsSeparatorSymbol : '.' // This will put the dollar sign at the end, with a space.
  })

  constructor(public toastCtrl:ToastController,public navCtrl: NavController,public params: NavParams, public listCat:ListCat,public loadingCtrl: LoadingController, public userService:UserService) {
    this.uid = this.params.get('dataUser').uid;
    this.stateVerification = this.params.get('stateVerification');

      // this.getCategory();
      this.categories();
    // this.getData(this.uid);
  }

    toggleDetails(data) {
      if (data.showDetails) {
          data.showDetails = false;
          data.icon = 'ios-add-circle-outline';
      } else {
          data.showDetails = true;
          data.icon = 'ios-remove-circle-outline';
      }
    }
    showHide(status,index){
      if(status==false){
        this.categoryData[index]['status']=true;
      }else{
        this.categoryData[index]['status']=false;
      }
    }
    sendValue(a,i,data){
      console.log(a,i,data);
      if(this.categoryData[a]['courses'][i]['class'] != 'active'){
        this.categoryData[a]['courses'][i]['class'] = 'active';
        this.sendData[a]['courses'][i]=data;
      }else{
        this.sendData[a]['courses'][i]['class']='inactive';
        this.categoryData[a]['courses'][i]['class'] = 'inactive';
      }
        console.log(this.sendData);
    }
    sendValueUmum(a,i,data){
      if(this.umum[0].data[a]['courses'][i]['class'] != 'active'){
        this.umum[0].data[a]['courses'][i]['class'] = 'active';
        this.sendData[5].data[a]['courses'][i]=data;
      }else{
        this.sendData[5].data[a]['courses'][i]['class']='inactive';
        this.umum[0].data[a]['courses'][i]['class'] = 'inactive';
      }
        console.log(this.umum[0].data[a].courses[i]);
        console.log(a);
        console.log(i);
        console.log(data);
    }

    dismiss(){
      this.navCtrl.pop();
    }
    send(){
      var that = this;
      if(that.sendDataUmum != undefined){
        that.sendDataUmum= that.sendData[5].data;
        _.remove(that.sendDataUmum,{price:''});
        console.log(that.sendDataUmum);
        for (let i = 0; i < this.sendDataUmum.length; i++) {
            _.remove(that.sendDataUmum[i].courses,{class:'inactive'});
            that.sendDataUmum[i].price = that.currencyToNum(that.sendDataUmum[i].price.replace(".",""));
        }
      }
      _.remove(this.sendData, {price:''});
      if(that.sendData.length == 0 && that.sendDataUmum.length == 0){
        that.presentAlert('Tidak ada produk yang terpilih, silahkan cek apabila anda belum memasukkan harga');
        return;
      }
      for (let i = 0; i < that.sendData.length; i++) {
        that.sendData[i].price = that.currencyToNum(that.sendData[i].price.replace(".",""));
        _.remove(that.sendData[i].courses, {class:'inactive'});
      }
      // this.sendData=_.chain(this.sendData)
      //                 .groupBy('parentId')
      //                 .toPairs()
      //                 .value();
      for (let i = 0; i < that.sendData.length; i++) {
          if(that.sendData[i].productId != undefined){
            that.listCat.updateProduct(that.sendData[i],that.sendData[i].key,that.uid);

          }
          else{
            that.listCat.newProduct(that.sendData[i],that.sendData[i].key,that.uid);
          }
      }
        if(that.sendDataUmum != undefined){
          for (let i = 0; i < that.sendDataUmum.length; i++) {
              if(that.sendDataUmum[i].productId != undefined){
                that.listCat.updateProduct(that.sendDataUmum[i],that.sendDataUmum[i].key,that.uid);

              }
              else{
                that.listCat.newProduct(that.sendDataUmum[i],that.sendDataUmum[i].key,that.uid);
              }
          }
        }
      if(that.stateVerification == 2){
        that.stateVerification =3;
        firebase.database().ref('users/'+that.uid).update({stateVerification:3});
        that.presentAlert('Produk anda telah tersimpan')
        return that.navCtrl.pop();

      }
      that.presentAlert('Perubahan product sedang menunggu approval')
      that.navCtrl.pop();
    }

    categories(){

      let loader=this.loadingCtrl.create({
        content:'<img src="./assets/loading.gif"/>',
        spinner:'hide'
      });
        loader.present();
      var that = this;
      that.listCat.getCourses().once('value',function(snapshot) {

        snapshot.forEach(function(childSnapshot){
        var raw = childSnapshot.val();
          raw.id= childSnapshot.key;
          raw.text = raw.name;
          var key = childSnapshot.parentId;
          raw.class='inactive';
          that.data.push(raw);

        });
        console.log(that.categoryData);
        console.log(that.data);
      }).then((getCat)=>{
      that.listCat.getCategory().once('value', function(snapshot){
        snapshot.forEach(function(childSnapshot){
          var data = childSnapshot.val();
          data.key = childSnapshot.key;
              data.show = false;
              data.price = '';
              data.status = false;
              if(data.key != -1){
                that.sendData.push(data);
                data.courses = _.remove(that.data, {parentId:data.key})
                that.categoryData.push(data);
              }
        })
        that.listCat.getTeacherProducts(that.uid).once('value',function(snapshot){
          console.log(snapshot.val());
          if(snapshot.val() != undefined || snapshot.val() != null){
                      snapshot.forEach(function(childSnapshot){
                          if(childSnapshot.val() != undefined){
                            console.log('nih child snapshot');
                            console.log(childSnapshot.val());
                            var dats = childSnapshot.val();
                            dats.productId = childSnapshot.key;
                            console.log(childSnapshot.key);
                            var index = _.findIndex(that.categoryData, {key: dats.categoryId});
                            var indexDat = _.findIndex(that.sendData, {key: dats.categoryId});
                            console.log(index);
                            childSnapshot.val().courses.forEach(function(asik){
                              var a = _.findIndex(that.categoryData[index].courses, {id:asik.id});
                              that.categoryData[index].courses[a].class="active";
                              that.sendData[indexDat].courses[a].id=asik.id;
                              that.sendData[indexDat].courses[a].class="active";
                              that.sendData[indexDat].courses[a].text=asik.text;
                              console.log(asik);
                            })
                            console.log(that.categoryData);
                            that.categoryData[index].price=dats.price;
                            that.categoryData[index].status=dats.status;
                            that.sendData[indexDat].price=dats.price;
                            that.sendData[indexDat].status=dats.status;
                            that.sendData[indexDat].productId=dats.productId;

                        }


                      })
          }
          that.categoryData[5].data=_.remove(that.categoryData, {parentId:'-KfQMIxSDCa1-T12Trze'});
          console.log(that.categoryData);
          console.log(that.umum);
          that.umum = _.remove(that.categoryData, {key:'-KfQMIxSDCa1-T12Trze'});
          that.sendData = _.union(that.categoryData,that.umum);
          console.log(that.sendData);
          loader.dismiss();
          })
      })
    })
    }


  checkData(){
      for (let i = 0; i < this.data; i++) {
          if(this.categoryData.length >0){
            return
          };
      }
    }

  presentAlert(message) {
      let toast = this.toastCtrl.create({
        message: message,
        duration: 3000,
        position: 'top'
      });
      toast.present();
   }
  getColor(a){
     return String.fromCharCode(97+a);
   }
  getBackColor(a, classic){
     var d =String.fromCharCode(97+a);
     if(classic != 'active'){
       return d = 'back'+d;
     }else{
       return d = 'back'+d+' '+'active';
     }
   }
  formatCurrency (num) {
    return num
       .toFixed(2) // always two decimal digits
       .replace(".", ",") // replace decimal point character with ,
       .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.") // use . as a separator
    }
  currencyToNum(num){
    console.log(num);
    var b = num.replace(".","").replace(".","").replace(".","");
    return b;
  }
}
