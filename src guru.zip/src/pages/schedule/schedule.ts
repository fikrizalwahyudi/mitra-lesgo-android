import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, ToastController,LoadingController } from 'ionic-angular';
import { UserService  } from '../../providers/user-service';
import { ListCat  } from '../../providers/list-cat';
import { ModalSchedulePage  } from '../modal-schedule/modal-schedule';
import * as _ from 'lodash';
import { Calendar } from '@ionic-native/calendar';

/*
  Generated class for the Schedule page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-schedule',
  templateUrl: 'schedule.html',
  providers: [UserService,ListCat]
})
export class SchedulePage {
  public onOff:any = false;
  public uid:any;
  public inactiveDate:any;
  public today:any=new Date();
  public state:any='ON';
  public schedule: any = {schedule:[{},{},{},{},{},{},{},{}]};
  public monday: any = false;
  public tuesday: any = false;
  public wednesday: any = false;
  public thursday: any = false;
  public friday: any = false;
  public saturday: any = false;
  public sunday: any = false;
  public mondayData: any=[];
  public tuesdayData: any=[];
  public wednesdayData: any=[];
  public thursdayData: any=[];
  public fridayData: any=[];
  public saturdayData: any=[];
  public sundayData: any=[];
  public stateVerification: any=[];

  constructor(private calendar:Calendar,public toastCtrl:ToastController,public loadingCtrl:LoadingController,public navCtrl: NavController, public params: NavParams, public modal:ModalController, public userService: UserService,public listCat: ListCat) {
    console.log(this.params);
    if(this.params.get('stateVerification') != undefined){
      this.stateVerification = this.params.get('stateVerification');
      this.uid = this.params.get('dataUser').uid;
    }else{
      this.stateVerification = 6;
      this.uid=this.params.get('uid');
    }
    if(this.stateVerification < 6){
      this.onOff = true;
    }
    this.getSchedule(this.uid);
     }
 dateClick(){
   if(this.monday != false && this.mondayData == undefined){
     this.monday = false;
   }
   else if(this.monday == false  && this.mondayData != undefined){
     this.monday = true;
   }
   else if(this.tuesday != false){
     this.tuesday = false;
   }
   else if(this.tuesday == false  && this.tuesdayData != undefined){
     this.tuesday = true;
   }
   else if(this.wednesday != false){
     this.wednesday = false;
   }
   else if(this.wednesday == false && this.wednesdayData != undefined){
     this.wednesday = true;
   }
   else if(this.thursday != false){
     this.thursday = false;
   }
   else if(this.thursday == false && this.thursdayData != undefined){
     this.thursday = true;
   }
   else if(this.friday != false){
     this.friday = false;
   }
   else if(this.friday == false && this.fridayData != undefined){
     this.friday = true;
   }
   else if(this.saturday != false){
     this.saturday = false;
   }
   else if(this.saturday == false && this.saturdayData != undefined){
     this.saturday = true;
   }
   else if(this.sunday != false){
     this.sunday = false;
   }
   else if(this.sunday == false && this.sundayData != undefined){
     this.sunday = true;
   }
 }
 openModal(name){
   var index = _.findIndex(this.schedule.schedule, {day:name});
   let scheduleModal = this.modal.create(ModalSchedulePage,{name:name,data:this.schedule.schedule[index]});
   scheduleModal.present();
   scheduleModal.onDidDismiss(data =>{
     console.log(data);

     if(data != undefined){
       if(data.day=='Monday'){
         if(data.status == true){
           this.schedule.schedule[1]=data;
           this.monday = true;
         }
         else{
           this.schedule.schedule[1].status=false;
           this.monday = false;
         }
       }
       else if(data.day=='Tuesday'){

         if(data.status == true){
           this.schedule.schedule[2]=data;
           this.tuesday = true;
         }
         else{
           this.schedule.schedule[2].status=false;
           this.tuesday =false;
         }
       }
       else if(data.day=='Wednesday') {

         if(data.status == true){
           this.schedule.schedule[3]=data;
           this.wednesday = true;
         }
         else{
           this.schedule.schedule[3].status=false;
           this.wednesday = false;
         }
       }
       else if(data.day=='Thursday'){

         if(data.status == true){
           this.schedule.schedule[4]=data;
           this.thursday = true;
         }
         else{
           this.schedule.schedule[4].status=false;
           this.thursday = false;
         }
       }
       else if(data.day=='Friday'){
         console.log('masuk');
         if(data.status == true){
           this.schedule.schedule[5]=data;
           this.friday = true;
         }
         else{
           this.schedule.schedule[5].status=false;
           this.friday = false;
         }
       }
       else if(data.day=='Saturday'){

         if(data.status == true){
           this.schedule.schedule[6]=data;
           this.saturday = true;
         }
         else{
           this.schedule.schedule[6].status=false;
           this.saturday = false;
         }
       }
       else if(data.day=='Sunday'){

         if(data.status == true){
           this.schedule.schedule[0]=data;
           this.sunday = true;
         }
         else{
           this.schedule.schedule[0].status=false;
           this.sunday = false;
         }
       }

     }

   })
 }
 updateSchedule(){

        let loading = this.loadingCtrl.create({
          content:'<img src="./assets/loading.gif"/>',
          spinner:'hide'})
        loading.present();
   if(this.schedule.schedule == undefined){
     this.presentAlert('tidak ada schedule yang terupdate, silahkan update terlebih dahulu');
     loading.dismiss();
     return;
   }
   var that = this;
   var keys=[]
   console.log(this.schedule);
   for (let i = 0; i < this.schedule.schedule.length; i++) {
     if(this.schedule.schedule[i] != undefined){
       _.remove(this.schedule.schedule[i].status, function(n){
         return n == false;
       });
     }
   }
   this.userService.updateSchedule(this.uid,this.schedule.schedule).then((success)=>{
     loading.dismiss();


     if(this.stateVerification < 3){
       this.presentAlert('Jadwal telah tersimpan');
       this.userService.viewUser(this.uid).update({stateVerification:2});
       this.navCtrl.pop();
     }else{
       this.presentAlert('Jadwal telah diubah');
       this.userService.viewTutorProfile(this.uid).update({status:this.onOff}).then(()=>{
         that.listCat.getTeacherProducts(that.uid).once('value',function(snaps){
           snaps.forEach(function(child){
             console.log(snaps);
             keys = child.key;
              that.listCat.searchProducts().child(keys).update({status:that.onOff});
           })
           that.navCtrl.pop();
         })
       })
     }
   },(error)=>{
     alert('error : '+error);
   });
 }
 getSchedule(uid){

     let loading = this.loadingCtrl.create({
       content:'<img src="./assets/loading.gif"/>',
       spinner:'hide'})
     loading.present();
   var that=this;
   this.userService.viewTutorProfile(uid).once('value',snapshot=>{
     if(snapshot.val().schedule.length == undefined || snapshot.val().schedule.length == 0){
     loading.dismiss();
       return;
     }
    that.schedule=snapshot.val();
    console.log(that.schedule);
    var monday = _.findIndex(that.schedule.schedule, {day:'Monday'});
    var tuesday = _.findIndex(that.schedule.schedule, {day:'Tuesday'});
    var wednesday = _.findIndex(that.schedule.schedule, {day:'Wednesday'});
    var thursday = _.findIndex(that.schedule.schedule, {day:'Thursday'});
    var friday = _.findIndex(that.schedule.schedule, {day:'Friday'});
    var saturday = _.findIndex(that.schedule.schedule, {day:'Saturday'});
    var sunday = _.findIndex(that.schedule.schedule, {day:'Sunday'});
    if(_.includes(that.schedule.schedule[sunday], true) == true){
      that.schedule.schedule[0]=that.schedule.schedule[sunday];
      that.sunday=true;
    } if(_.includes(that.schedule.schedule[monday],true)  == true){
      that.schedule.schedule[1]=that.schedule.schedule[monday];
      that.monday=true;
    } if(_.includes(that.schedule.schedule[tuesday],true) == true){
      that.schedule.schedule[2]=that.schedule.schedule[tuesday];
      that.tuesday=true;
    } if(_.includes(that.schedule.schedule[wednesday],true) == true){
      that.schedule.schedule[3]=that.schedule.schedule[wednesday];
      that.wednesday=true;
    } if(_.includes(that.schedule.schedule[thursday],true) == true){
      that.schedule.schedule[4]=that.schedule.schedule[thursday];
      that.thursday=true;
    } if(_.includes(that.schedule.schedule[friday],true) == true){
      that.schedule.schedule[5]=that.schedule.schedule[friday];
      that.friday=true;
    } if(_.includes(that.schedule.schedule[saturday],true) == true){
      that.schedule.schedule[6]=that.schedule.schedule[saturday];
      that.saturday=true;
    }
    if(that.stateVerification != undefined || that.stateVerification >5){
      that.onOff=that.schedule.status;
    }
    loading.dismiss();
    console.log(that.schedule);
   })
 }
 dismiss(){
   this.navCtrl.pop();
 }
 presentAlert(message) {
   let toast = this.toastCtrl.create({
     message: message,
     duration: 3000,
     position: 'top'
   });
   toast.present();
}
  openCalendar(){
    this.calendar.openCalendar(this.today);
  }

}
