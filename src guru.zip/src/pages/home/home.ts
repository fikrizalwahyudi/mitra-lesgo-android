import { Component,ViewChild } from '@angular/core';
import { NavController, ViewController,AlertController,LoadingController, NavParams,ModalController, ActionSheetController,ToastController, Platform, Content, Loading } from 'ionic-angular';
import { UserService  } from '../../providers/user-service';
import { Zapier } from '../../providers/zapier';
import { KelasPage  } from '../kelas/kelas';
import { SettingPage  } from '../setting/setting';
import { ReviewPage  } from '../review/review';
import { BookingPage  } from '../booking/booking';
import { SchedulePage  } from '../schedule/schedule';
import { VerificationPage  } from '../verification/verification';
import { CustomerservicePage  } from '../customerservice/customerservice';
import * as firebase from 'firebase';
import { FilePath } from '@ionic-native/file-path';
import { FileOpener } from '@ionic-native/file-opener';
import { FileChooser } from '@ionic-native/file-chooser';
import { Transfer, FileUploadOptions, TransferObject } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/Camera';
import { Network } from '@ionic-native/network';
import { ErrorPage  } from '../error/error';

declare var cordova: any
declare var window;
/*
  Generated class for the Home page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers:[UserService]
})
export class HomePage {
  @ViewChild(Content) content: Content;
  public user:any=[];
  public loading: Loading;
  public today:any;
  public myUserId:any;
  public cartData:any=[];
  public cartStatus:any;
  public cartId:any;
  public chatData:any=[];
  public orderData:any=[];
  public sessionData:number=0;
  public schedule:any=[];
  public role:any;
  public latLng:any= {lat:0,lng:0};
  public smsVerification:any;
  public murid:any=[];
  public status:any=false;
  public smsVerificationCode:any;

  constructor(public network:Network,public zapier:Zapier, public actionSheetCtrl: ActionSheetController,public toastCtrl: ToastController, private Camera:Camera, private File:File, private FilePath:FilePath, private FileChooser:FileChooser,public navCtrl: NavController,public params: NavParams, public userService: UserService, public alertCtrl: AlertController,public loadingCtrl: LoadingController,public modalCtrl: ModalController) {
    // this.updateDatabase();


    // this.displayUser(this.myUserId);

  }
    ionViewWillEnter(){

        let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
          disconnectSubscription.unsubscribe();
          let a = this.loadingCtrl.create();
          a.dismissAll();
          this.navCtrl.push(ErrorPage);
    });
      this.myUserId = firebase.auth().currentUser.uid;
      this.getUser();
    }
    getUser(){
      let loader=this.loadingCtrl.create({
        content:'<img src="./assets/loading.gif"/>',
        spinner:'hide'
      });
        var that=this;
        this.userService.getUserDataOnce(this.myUserId).subscribe(snapshot  =>  {
          console.log(snapshot.val());
          var data = snapshot.val();
          this.user = data;
          this.user.userId = snapshot.key;
          if(data.stateVerification<4){
            let tutorAlert = this.alertCtrl.create({
            title:'Selamat datang di Lesgo!',
            enableBackdropDismiss:false,
            message:'Anda belum terverifikasi sebagai Mitra Guru LESGO!. Silahkan melakukan verifikasi terlebih dahulu.',
            buttons: [
                      {
                        text: 'Lesgo!',
                        handler: () => {
                          this.navCtrl.setRoot(VerificationPage, {dataUser:data});
                        }
                      }
                    ]
                  });
                  if(data.smsVerificationStatus != true){
                    let alert = this.alertCtrl.create({
                        title: 'Verifikasi HP',
                        message: 'Isi kode verifikasi Anda',
                        enableBackdropDismiss:false,
                        inputs: [
                                  {
                                    name: 'code',
                                    placeholder: 'Kode Anda'
                                  }
                                ],
                        buttons: [
                          {
                            text: 'Resend Code',
                            handler: datas => {
                              let smsobj = { phoneNumber: data.phoneNumber, email :data.email, verificationCode:data.smsVerificationCode,textMessage:"Ini adalah verification code dari LESGO!"};
                              that.userService.resendSms(smsobj).subscribe(res =>{
                                alert.setMessage('<span style="color:green !important;">Kode verifikasi Anda telah terkirim</span>')
                              },error => {
                                });
                                return false;
                            }
                          },
                          {
                            text: 'Confirm',
                            handler: datas => {
                              if(data.smsVerificationCode == datas.code){
                                this.userService.viewUser(snapshot.key).update({smsVerificationStatus:true}).then(ok =>{
                                  tutorAlert.present();
                                  return true;
                                })
                              }
                              else{
                                alert.setMessage('<span style="color:red !important;">Kode verifikasi Anda salah, silahkan coba lagi</span>')
                                return false;
                              }
                            }
                          }
                        ]
                      });
                      alert.present();
                    loader.dismissAll();
                  }else{
                    tutorAlert.present();
                  }
          }else if(data.stateVerification<7){
            let tutorAlert = this.alertCtrl.create({
              title:'Selamat datang di Lesgo!',
              enableBackdropDismiss:false,
              message:'Aplikasi anda telah disetujui. Lanjutkan proses administrasi Anda.',
              buttons: [
                        {
                          text: 'Next',
                          handler: () => {
                            this.navCtrl.setRoot(VerificationPage, {dataUser:data});
                          }
                        }
                      ]
                    });
                    console.log(this.user);
                    tutorAlert.present();
          }
          else{
              that.chatNotificationCs();
              that.chatNotificationMurid();
              that.totalOrder();
              console.log(that.user)
            that.status = true;
            loader.dismissAll();
          }
        })
    }
    public uploadImage(data,fileType) {
    // Destination URL
    let storageRef = firebase.storage().ref(this.user.userId);

    const filename = fileType;
    const imageRef = storageRef.child(`${filename}.png`);

      this.loading = this.loadingCtrl.create({
        content:'<img src="./assets/loading.gif"/>',
        spinner:'hide'
      });
    this.loading.present();
      imageRef.putString(data, 'base64', {contentType:'image/jpg'}).then((snapshot)=> {
        var that=this;
          that.user.avatar = snapshot.downloadURL;
          that.loading.dismissAll()

      }, err => {
        this.presentToast('Error while uploading file');
      });

  }

  chatNotificationCs(){
    var that = this;
    this.userService.getChatCsStatus(this.myUserId).subscribe(snapshot=>{
      console.log(snapshot);
      if(snapshot.length != 0){
        that.chatData.cs = [];
        snapshot.forEach(o=>{
          if(o.status == false){
            that.chatData.cs.push(o);
          }
        })
      }
    })
  }
  chatNotificationMurid(){
    var that = this;
    this.userService.getChatTutorStatus(this.myUserId).subscribe(snapshot=>{
      that.chatData=[];
      console.log(snapshot);
      if(snapshot.length != 0){
        that.chatData.murid = [];
          snapshot.forEach(o=>{
            if(o.status == false){
              that.chatData.murid.push(o);
            }
          })
      }
    })
  }
  totalOrder(){
    var that = this;
    that.userService.tutorCariMurid(that.myUserId).subscribe(snapshot=>{
      that.orderData=[];
      that.sessionData=0;
      if(snapshot.length!=0){
        that.orderData=[];
        that.sessionData =0;
        snapshot.forEach(a=>{
          if(a.status=='booked'){
            that.orderData.push(a);
            that.sessionData=that.sessionData+a.sessions.length;
          }
        })
      }

    })
  }

  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

  // Always get the accurate path to your apps folder
  public pathForImage(img) {
    if (img === null) {
      return '';
    } else {
      return cordova.file.dataDirectory + img;
    }
  }
    public takePicture(sourceType, fileType) {
      // Create options for the Camera Dialog
      const options : CameraOptions = {
        quality: 50,
        sourceType: sourceType,
        saveToPhotoAlbum: true,
        allowEdit : true,
        targetWidth : 600,
        targetHeight : 600,
        destinationType: 0,
        encodingType: this.Camera.EncodingType.JPEG,
        mediaType: 0,
        correctOrientation : true
      };

      // Get the data of an image
      this.Camera.getPicture(options).then((imagePath) => {
        // Special handling for Android library
          this.uploadImage(imagePath,fileType);
      }, (err) => {
        this.presentToast('Foto tidak terpilih');
      });
    }

     public presentActionSheet(fileType) {
       let actionSheet = this.actionSheetCtrl.create({
         title: 'Select Image Source',
         buttons: [
           {
             text: 'Load from Library',
             handler: () => {
               this.takePicture(0, fileType);
             }
           },
           {
             text: 'Use Camera',
             handler: () => {
               this.takePicture(1, fileType);
             }
           },
           {
             text: 'Cancel',
             role: 'cancel'
           }
         ]
       });
       actionSheet.present();
     }
  navigateMe(name:string){
    if(name == 'BookingPage'){
      this.navCtrl.push(BookingPage, {uid:this.myUserId});
    }
    else if(name == 'SchedulePage'){
      this.navCtrl.push(SchedulePage, {uid:this.myUserId});
    }
    else if(name == 'CustomerservicePage'){
      this.navCtrl.push(CustomerservicePage, {data:this.myUserId,name:this.user.firstName});
    }
    else if(name == 'Report'){
      this.navCtrl.push(ReviewPage, {uid:this.myUserId,dataUser:{firstName:this.user.firstName, lastName:this.user.lastName, avatar:this.user.avatar}});
    }
    else if(name == 'Class'){
      this.navCtrl.push(KelasPage, {dataUser:{uid:this.myUserId},name:this.user.firstName});
    }
    else if(name == 'SettingPage'){
      this.navCtrl.push(SettingPage);
    }
  }
  sendEmail(){
    this.zapier.sendNotification({message:'Anda telah memesan guru Puja Altiar, yang akan mengajar pada 10 maret 2021 (ini test btw)',title:'Anda mempunya order',to:'de5aoAe80lk:APA91bG41x4yMQbbswn5YptnpZZWS58hUBHHRwqLpuwJkVsbQVMqA5wZVrQ_gA15LxbRhqObV7S9BLr3K6OCsgXAQPyIdppc2Sk6ilobJQ2mX4RUsHQDFCNK3wEJrwGY30MhdxCo-x_j'}).subscribe(success=>{

    })
  }

}
