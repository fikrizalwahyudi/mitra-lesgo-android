import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, AlertController,ActionSheetController, ModalController, ToastController, Platform, Content, LoadingController, Loading} from 'ionic-angular';
import { UserService  } from '../../providers/user-service';
import { FilePath } from '@ionic-native/file-path';
import { FileOpener } from '@ionic-native/file-opener';
import { FileChooser } from '@ionic-native/file-chooser';
import { Transfer, FileUploadOptions, TransferObject } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/Camera';
import * as firebase from 'firebase';
import * as _ from 'lodash';
import * as moment from 'moment';
import { IonicImageViewerModule } from 'ionic-img-viewer';

/*
  Generated class for the Customeservice page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/declare var cordova: any
declare var window;
@Component({
  selector: 'page-customerservice',
  templateUrl: 'customerservice.html',
  providers:  [UserService]
})
export class CustomerservicePage {
  @ViewChild(Content) content: Content;
  public theChat:any;
  public receiver:any;
  public name:any;
  public lastImage: string = null;
  public loading: Loading;
  public captureDataUrl:any;
  private chatData:any = [];
  public uid:any;
  public offset:any;

  constructor(private Camera:Camera, private File:File, private FilePath:FilePath, private FileChooser:FileChooser, public navCtrl: NavController, public params: NavParams,public userService: UserService, public alertCtrl: AlertController, public modalCtrl:ModalController,  public actionSheetCtrl: ActionSheetController, public toastCtrl: ToastController
    , public platform: Platform, public loadingCtrl: LoadingController) {
    var that = this;
    console.log(this.params);
    this.uid = this.params.get('data');
    this.name = this.params.get('name');
    let loader=this.loadingCtrl.create({
      content:'<img src="./assets/loading.gif"/>',
      spinner:'hide',
      duration: 500
    });
    loader.present()
    // this.userService.myChatsGuru(this.uid,'cs').once('value').then(function(snapshot){
    //   var data=[];
    //   snapshot.forEach(function(childData){
    //     console.log(childData);
    //     var dats = childData.val();
    //     dats['key']=childData.key;
    //     that.ChatData.push(dats);
    //   });
    //   console.log(that.ChatData);
    //   return that.ChatData.push(data);
    // });

    this.updateChat();
    loader.dismiss();
  }

  dismiss(){
    this.offset.unsubscribe();
    this.navCtrl.pop();
  }
  updateChat(){
    var that= this;

    this.offset = this.userService.newChatCs(this.uid).subscribe(snapshot =>{
      that.chatData=snapshot;
      var count = 0;
      if(snapshot.length == 0){
          this.userService.sendFirstChat(this.uid,this.name)
      }else{
          snapshot.forEach(e =>{
            if(e.position == 'left' && e.status == false){
              count=count+1;
                that.userService.updateChatStatus(e.$key,this.uid);
            }
          })
          if(count !=0){
            that.presentToast('Ada chat dari CS');
            return that.scrollToBottom();
          }
      }
      console.log(this.chatData);
      console.log(snapshot);
    })
  }
    openThis(name:string){
      if(name == 'back'){
        this.navCtrl.pop();
        }
      }
      sendChat(){
        this.userService.sendChatCsNew(this.theChat,this.uid,this.name,'text');
        console.log(this.theChat);
        this.theChat= null;
      }
      getDates(dates){
      //  var date = new Date(0);
      //  date.setUTCMilliseconds(dates);
      //  date.toLocaleString();
      //  var day = date.getDate();
      //   var monthIndex = date.getMonth();
      //   var year = date.getFullYear();
      //   var minutes = date.getMinutes();
      //   var hours = date.getHours();
      //   var format = day+"/"+monthIndex+"/"+year+" "+hours+":"+minutes;
       return moment(dates).format('DD/MM/YYYY');
      }
      getHour(hour){
        var a = new Date(hour).getHours();
        var b = new Date(hour).getMinutes();
        if(b > 9){
          return a+':'+b;
        }else{
          return a+':0'+b;
        }
      }

      private createFileName() {
      var d = new Date(),
      n = d.getTime(),
      newFileName =  n + ".jpg";
      return newFileName;
    }

      public uploadImage(data) {
      // Destination URL
      let storageRef = firebase.storage().ref(this.uid+'/cs/');

      const filename = new Date().getTime();
      const imageRef = storageRef.child(`${filename}.png`);

      this.loading = this.loadingCtrl.create({
      });
      this.loading.present();
        imageRef.putString(data, 'base64', {contentType:'image/jpg'}).then((snapshot)=> {
            this.userService.sendChatCsNew(snapshot.downloadURL,this.uid,this.name,'img');
          this.loading.dismissAll()
        }, err => {
          this.loading.dismissAll()
        });

    }


    private presentToast(text) {
      let toast = this.toastCtrl.create({
        message: text,
        duration: 3000,
        position: 'top'
      });
      toast.present();
    }

    // Always get the accurate path to your apps folder
    public pathForImage(img) {
      if (img === null) {
        return '';
      } else {
        return cordova.file.dataDirectory + img;
      }
    }
      public takePicture(sourceType) {
        // Create options for the Camera Dialog
        const options : CameraOptions = {
          quality: 50,
          sourceType: sourceType,
          saveToPhotoAlbum: true,
          allowEdit : true,
          targetWidth : 600,
          targetHeight : 600,
          destinationType: 0,
          encodingType: this.Camera.EncodingType.JPEG,
          mediaType: 0,
          correctOrientation : true
        };

        // Get the data of an image
        this.Camera.getPicture(options).then((imagePath) => {
          // Special handling for Android library
                this.uploadImage(imagePath);
        }, (err) => {
        });
      }

      scrollToBottom() {
           setTimeout(() => {
               this.content.scrollToBottom(300);
           });
       }

       public presentActionSheet() {
         let actionSheet = this.actionSheetCtrl.create({
           title: 'Select Image Source',
           buttons: [
             {
               text: 'Load from Library',
               handler: () => {
                 this.takePicture(0);
               }
             },
             {
               text: 'Use Camera',
               handler: () => {
                 this.takePicture(1);
               }
             },
             {
               text: 'Cancel',
               role: 'cancel'
             }
           ]
         });
         actionSheet.present();
       }

       update(){
           this.content.resize();
       }
}
