import { Component, ViewChild } from '@angular/core';
import { NavController, AlertController, ActionSheetController, NavParams, ModalController, ToastController, Platform, Content, LoadingController, Loading } from 'ionic-angular';
import { UserService  } from '../../providers/user-service';
import { LoginPage  } from '../login/login';
import { MapsPage  } from '../maps/maps';
import  * as firebase from 'firebase';
// import { ImagePicker,Camera, File, Transfer, FilePath, FileChooser} from 'ionic-native';
// , File, Transfer, FilePath, FileChooser
import { FilePath } from '@ionic-native/file-path';
import { FileOpener } from '@ionic-native/file-opener';
import { FileChooser } from '@ionic-native/file-chooser';
import { Transfer, FileUploadOptions, TransferObject } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { Camera, CameraOptions } from '@ionic-native/Camera';
import { TextMaskModule } from 'angular2-text-mask';


declare var cordova: any
declare var window;
// import { GalleryPage } from '../gallery/gallery';
/*
  Generated class for the Profile page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
  providers:  [UserService]
})
export class ProfilePage {
  @ViewChild(Content) content: Content;
  public userGenderState:any=false;
  public userAvatar:any;
  public userLatLong:any={lat:0,long:0};
  public lastImage: string = null;
  public loading: Loading;
  public captureDataUrl:any;
  public listMurid:any=[];
  public numsky:any;
  public select:any;
  public email:any;
  public jumlahMurid:any=0;
  public dataMurid:any=[];
  public dataTutor:any=[];
  public dataUser:any={avatar:"assets/Male.png",firstName:"",lastName:"",gender:"",alamat:"",provinceId:"",provinceName:"",cityId:"",cityName:"",posCode:"",latitude:"",longitude:"",dob:"",uid:"",updatedAt:"",displayAddress:""};
  public province:any = [
      {
        id:0,
        name:'DKI Jakarta'
      },
      {
        id:1,
        name:'Bali'
      },
      {
        id:2,
        name:'Banten'
      },
      {
        id:3,
        name:'Bengkulu'
      },
      {
        id:4,
        name:'D.I Yogyakarta'
      },
      {
        id:5,
        name:'Gorontalo'
      },
      {
        id:6,
        name:'Jambi'
      },
      {
        id:7,
        name:'Jawa Barat'
      },
      {
        id:8,
        name:'Jawa Tengah'
      },
      {
        id:9,
        name:'Jawa Timur'
      },
      {
        id:10,
        name:'Kalimantan Selatan'
      },
      {
        id:11,
        name:'Kalimantan Tengah'
      },
      {
        id:12,
        name:'Kalimantan Timur'
      },
      {
        id:13,
        name:'Kalimatan Barat'
      },
      {
        id:14,
        name:'Bangka Belitung'
      },
      {
        id:15,
        name:'Kepulauan Riau'
      },
      {
        id:16,
        name:'Lampung'
      },
      {
        id:17,
        name:'Maluku'
      },
      {
        id:18,
        name:'Maluku Utara'
      },
      {
        id:19,
        name:'Nanggroe Aceh Darussalam'
      },
      {
        id:20,
        name:'Nusa Tenggara Barat'
      },
      {
        id:21,
        name:'Nusa Tenggara Timur'
      },
      {
        id:22,
        name:'Papua'
      },
      {
        id:23,
        name:'Papua Barat'
      },
      {
        id:24,
        name:'Riau'
      },
      {
        id:25,
        name:'Sulawesi Barat'
      },
      {
        id:26,
        name:'Sulawesi Selatan'
      },
      {
        id:27,
        name:'Sulawesi Tengah'
      },
      {
        id:28,
        name:'Sulawesi Tenggara'
      },
      {
        id:29,
        name:'Sulawesi Utara'
      },
      {
        id:30,
        name:'Sumatera Barat'
      },
      {
        id:31,
        name:'Sumatera Selatan'
      },
      {
        id:32,
        name:'Sumatera Utara'
      }
    ];

    public city:any = [
      {
        id:0,
        name:['Jakarta Barat',
              'Jakarta Timur',
              'Jakarta Selatan',
              'Jakarta Pusat',
              'Jakarta Utara',
              'Kep Seribu'],
        provinceId:0
      },
      {
        id:1,
        name:['Badung',
              'Bangli',
              'Buleleng',
              'Denpasar',
              'Gianyar',
              'Jembrana',
              'Karangasem',
              'Klungkung',
              'Tabanan'],
        provinceId:1
      },
      {
        id:2,
        name:['Cilegon',
              'Kabupaten Serang',
              'Kabupaten Tangerang',
              'Lebak',
              'Pandeglang',
              'Serang',
              'Tangerang',
              'Tangerang Selatan'],
        provinceId:2
      },
      {
        id:3,
        name:['Bengkulu',
              'Bengkulu Selatan',
              'Bengkulu Tengah',
              'Bengkulu Utara',
              'Kaur',
              'Kepahiang',
              'Lebong',
              'Muko Muko',
              'Rejang Lebong',
              'Seluma'],
        provinceId:3
      },
      {
        id:4,
        name:['Bantul',
              'Gunung Kidul',
              'Kulon Progo',
              'Sleman',
              'Yogyakarta'],
        provinceId:4
      },
      {
        id:5,
        name:['Boalemo',
              'Bone Bolango',
              'Gorontalo',
              'Gorontalo Utara',
              'Kabupaten Gorontalo',
              'Pahuwato'],
        provinceId:5
      },
      {
        id:6,
        name:['Batang Hari',
              'Bungo',
              'Jambi',
              'Kerinci',
              'Merangin',
              'Muaro Jambi',
              'Sorolangun',
              'Sungai Penuh',
              'Tanjung Jabung Barat',
              'Tanjung Jabung Timur',
              'Tebo'],
        provinceId:6
      },
      {
        id:7,
        name:['Bandung',
              'Bandung Barat',
              'Banjar',
              'Bekasi',
              'Bogor',
              'Ciamis',
              'Cianjur',
              'Cimahi',
              'Depok',
              'Garut',
              'Indramayu',
              'Kabupaten Bandung',
              'Kabupaten Bekasi',
              'Kabupaten Bogor',
              'Kabupaten Cirebon',
              'Kabupaten Sukabumi',
              'Kabupaten Tasikmalaya',
              'Karawang',
              'Kota Cirebon',
              'Kota Sukabumi',
              'Kota Tasikmalaya',
              'Kuningan',
              'Purwakarta',
              'Subang',
              'Sumedang'],
        provinceId:7
      },
      {
        id:8,
        name:['Banjarnegara',
              'Banyumas',
              'Batang',
              'Blora',
              'Boyolali',
              'Brebes',
              'Cilacap',
              'Demak',
              'Grobogan',
              'Kabupaten Pekalongan',
              'Kabupaten Semarang',
              'Kabupaten Tegal',
              'Karanganyar',
              'Kebumen',
              'Kendal',
              'Klaten',
              'Kota Pekalongan',
              'Kota Tegal',
              'Kudus',
              'Magelang',
              'Pati',
              'Pemalang',
              'Purbalingga',
              'Purworejo',
              'Rembang',
              'Salatiga',
              'Semarang',
              'Sragen',
              'Sukoharjo',
              'Surakarta',
              'Temanggung',
              'Wonogiri',
              'Wonosobo'],
        provinceId:8
      },
      {
        id:9,
        name:['Bangkalan',
              'Banyuwangi',
              'Batu',
              'Bojonegoro',
              'Bondowoso',
              'Gresik',
              'Jember',
              'Jombang',
              'Kabupaten Blitar',
              'Kabupaten Kediri',
              'Kabupaten Madiun',
              'Kabupaten Malang',
              'Kabupaten Mojokerto',
              'Kabupaten Pasuruan',
              'Kabupaten Probolinggo',
              'Kota Blitar',
              'Kota Kediri',
              'Kota Madiun',
              'Kota Malang',
              'Kota Mojokerto',
              'Kota Pasuruan',
              'Kota Probolinggo',
              'Lamongan',
              'Lumajang',
              'Magetan',
              'Nganjuk',
              'Ngawi',
              'Pacitan',
              'Pamekasan',
              'Ponorogo',
              'Sampang',
              'Sidoarjo',
              'Situbondo',
              'Sumenep',
              'Surabaya',
              'Trenggalek',
              'Tuban',
              'Tulungagung'],
        provinceId:9
      },
      {
        id:10,
        name:['Balangan',
              'Banjar',
              'Banjarbaru',
              'Banjarmasin',
              'Barito Kuala',
              'Hulu Sungai Selatan',
              'Hulu Sungai Tengah',
              'Hulu Sungai Utara',
              'Kotabaru',
              'Tanah Bumbu',
              'Tanah Laut',
              'Tapin'],
        provinceId:10
      },
      {
        id:11,
        name:['Barito Timur',
              'Barito Selatan',
              'Barito Utara',
              'Gunung Mas',
              'Kapuas',
              'Katingan',
              'Kotawaringin Barat',
              'Kotawaringin Timur',
              'Murung Raya',
              'Palangka Raya',
              'Pulau Pisau',
              'Seruyan',
              'Sukamara'],
        provinceId:11
      },
      {
        id:12,
        name:['Balikpapan',
              'Berau',
              'Bontang',
              'Bulungan',
              'Kutai Barat',
              'Kutai Kertanegara',
              'Kutai Timur',
              'Malinau',
              'Nunukan',
              'Paser',
              'Penajam Paser Utara',
              'Samarinda',
              'Tana Tidung',
              'Tarakan'],
        provinceId:12
      },
      {
        id:13,
        name:['Bengkayang',
              'Kabupaten Pontianak',
              'Kapuas Hulu',
              'Kayong Utara',
              'Ketapang',
              'Kubu Raya',
              'Landak',
              'Melawai',
              'Pontianak',
              'Sambas',
              'Sanggau',
              'Sekadau',
              'Singkawang',
              'Sintang'],
        provinceId:13
      },
      {
        id:14,
        name:['Bangka',
              'Bangka Barat',
              'Bangka Selatan',
              'Bangka Tengah',
              'Belitung',
              'Belitung Timur',
              'Pangkal Pinang'],
        provinceId:14
      },
      {
        id:15,
        name:['Batam',
              'Bintan',
              'Karimun',
              'Kepulauan Anambas',
              'Lingga',
              'Natuna',
              'Tanjung Pinang'],
        provinceId:15
      },
      {
        id:16,
        name:['Bandar Lampung',
              'Lampung Barat',
              'Lampung Selatan',
              'Lampung Tengah',
              'Lampung Timur',
              'Lampung Utara',
              'Mesuji',
              'Metro',
              'Pesawaran',
              'Pringsewu',
              'Tanggamus',
              'Tulang Bawang',
              'Tulang Bawang Barat',
              'Way Kanan'],
        provinceId:16
      },
      {
        id:17,
        name:['Ambon',
              'Buru',
              'Buru Selatan',
              'Kepulauan Aru',
              'Maluku Barat Daya',
              'Maluku Tengah',
              'Maluku Tenggara',
              'Maluku Tenggara Barat',
              'Seram Bagian Barat',
              'Seram Bagian Timur',
              'Tual'],
        provinceId:17
      },
      {
        id:18,
        name:['Halmahera Barat',
              'Halmahera Selatan',
              'Halmahera Tengah',
              'Halmahera Timur',
              'Halmahera Utara',
              'Kepulauan Morotai',
              'Kepulauan Sula',
              'Sofifi',
              'Ternate',
              'Tidore Kepulauan'],
        provinceId:18
      },
      {
        id:19,
        name:['Aceh Barat',
              'Aceh Barat Daya',
              'Aceh Besar',
              'Aceh Jaya',
              'Aceh Selatan',
              'Aceh Singkil',
              'Aceh Tamiang',
              'Aceh Tengah',
              'Aceh Tenggara',
              'Aceh Timur',
              'Aceh Utara',
              'Banda Aceh',
              'Bener Meriah',
              'Bireuen',
              'Gayo Lues',
              'Langsa',
              'Lhokseumawe',
              'Nagan Raya',
              'Pidie',
              'Pidie JayaSabang',
              'Sabang',
              'Simeulue',
              'Subulussalam'],
        provinceId:19
      },
      {
        id:20,
        name:['Dompu',
              'Kabupaten Bima',
              'Kota Bima',
              'Lombok Barat',
              'Lombok Tengah',
              'Lombok Timur',
              'Lombok Utara',
              'Mataram',
              'Sumbawa',
              'Sumbawa Barat'],
        provinceId:20
      },
      {
        id:21,
        name:['Alor',
              'Belu',
              'Ende',
              'Flores Timur',
              'Kabupaten Kupang',
              'Kupang',
              'Lembata',
              'Manggarai',
              'Manggarai Barat',
              'Manggarai Timur',
              'Nagekeo',
              'Ngada',
              'Rote Ndao',
              'Sabu Raijua',
              'Sikka',
              'Sumba Barat',
              'Sumba Barat Daya',
              'Sumba Tengah',
              'Sumba Timur',
              'Timor Tengah Selatan',
              'Timor Tengah Utara'],
        provinceId:21
      },
      {
        id:22,
        name:['Asmat',
              'Biak Numfor',
              'Boven Digoel',
              'Deiyai',
              'Dogiyai',
              'Intan Jaya',
              'Jayapura',
              'Jayawijaya',
              'Kabupaten Jayapura',
              'Keerom',
              'Lanny Jaya',
              'Mamberamo Raya',
              'Mappi',
              'Membramo Tengah',
              'Merauke',
              'Mimika',
              'Nabire',
              'Nduga',
              'Paniai',
              'Pegunungan Bintang',
              'Puncak',
              'Puncak Jaya',
              'Sarmi',
              'Supiori',
              'Tolikara',
              'Yahukimo',
              'Yalimo',
              'Yapen Waropen'],
        provinceId:22
      },
      {
        id:23,
        name:['Fakfak',
              'Kabupaten Sorong',
              'Kaimana',
              'Kota Sorong',
              'Manokwari',
              'Maybrat',
              'Raja Ampat',
              'Sorong Selatan',
              'Tambrauw',
              'Teluk Bintuni',
              'Teluk Wondama'],
        provinceId:23
      },
      {
        id:24,
        name:['Bengkalis',
              'Dumai',
              'Indragiri Hilir',
              'Indragiri Hulu',
              'Kampar',
              'Kepulauan Meranti',
              'Kuantan Singingi',
              'Pekan Baru',
              'Pelalawan',
              'Rokan Hilir',
              'Rokan Hulu',
              'Siak'],

        provinceId:24
      },
      {
        id:25,
        name:['Majene',
              'Mamasa',
              'Mamuju',
              'Mamuju Utara',
              'Polewali Mandar'],
        provinceId:25
      },
      {
        id:26,
        name:['Bantaeng',
              'Barru',
              'Buleleng',
              'Bone',
              'Bulukumba',
              'Enrekang',
              'Gowa',
              'Jeneponto',
              'Kepulauan Selayar',
              'Luwu',
              'Luwu Timur',
              'Luwu Utara',
              'Makassar',
              'Maros',
              'Palopo',
              'Pangkajene Kepulauan',
              'Pare Pare',
              'Pinrang',
              'Sidenreng Rapang',
              'Sinjai',
              'Soppeng',
              'Takalar',
              'Tana Toraja',
              'Toraja Utara',
              'Wajo'],
        provinceId:26
      },
      {
        id:27,
        name:['Banggai',
              'Banggai Kepulauan',
              'Buol',
              'Donggala',
              'Morowali',
              'Palu',
              'Parigi Moutong',
              'Poso',
              'Sigi',
              'Tojo Una Una',
              'Toli Toli'],
        provinceId:27
      },
      {
        id:28,
        name:['Bombana',
              'Wakatobi',
              'Kolaka Utara',
              'Konawe Selatan',
              'Konawe Utara',
              'Buton Utara',
              'Kolaka Timur',
              'Konawe Kepulauan',
              'Konawe',
              'Buton Tengah',
              'Buton Selatan',
              'Muna Barat'],
        provinceId:28
      },
      {
        id:29,
        name:['Bitung',
              'Bolaang Mongondow',
              'Bolaang Mongondow Selatan',
              'Bolaang Mongondow Timur',
              'Bolmong Utara',
              'Kepulauan Sangihe',
              'Kepulauan Siau Tagulandang Biaro',
              'Kepulauan Talaud',
              'Kotamobagu',
              'Manado',
              'Minahasa',
              'Minahasa Selatan',
              'Minahasa Tenggara',
              'Minahasa Utara',
              'Tomohon'],
        provinceId:29
      },
      {
        id:30,
        name:['Agam',
              'Bukittinggi',
              'Dharmasraya',
              'Kepulauan Mentawai',
              'Lima Puluh Kota',
              'Padang',
              'Padang Panjang',
              'Padang Pariaman',
              'Pariaman',
              'Pasaman',
              'Pasaman Barat',
              'Payakumbuh',
              'Pesisir Selatan',
              'Sawah Lunto',
              'Sijunjung',
              'Solok',
              'Solok Selatan',
              'Tanah Datar'],
        provinceId:30
      },
      {
        id:31,
        name:['Banyuasin',
              'Empat Lawang',
              'Lahat',
              'Lubuk Linggau',
              'Muara Enim',
              'Musi Banyuasin',
              'Musi Rawas',
              'Ogan Ilir',
              'Ogan Komering Ilir',
              'Ogan Komering Ulu',
              'Oku Selatan',
              'Oku Timur',
              'Pagar Alam',
              'Palembang',
              'Prabumulih'],
        provinceId:31
      },
      {
        id:32,
        name:['Asahan',
              'Batubara',
              'Binjai',
              'Dairi',
              'Deli Serdang',
              'Gunung Sitoli',
              'Humbang Hasundutan',
              'Karo',
              'Labuhan Batu',
              'Labuhan Batu Selatan',
              'Labuhan Batu Utara',
              'Langkat',
              'Mandailing Natal',
              'Medan',
              'Nias',
              'Nias Barat',
              'Nias Selatan',
              'Nias Utara',
              'Padang Lawas',
              'Padang Lawas Utara',
              'Padang Sidempuan',
              'Pakpak Bharat',
              'Pematang Siantar',
              'Samosir',
              'Serdang Bedagai',
              'Sibolga',
              'Simalungun',
              'Tanjung Balai',
              'Tapanuli Selatan',
              'Tapanuli Tengah',
              'Tapanuli Utara',
              'Tebing Tinggi',
              'Toba Samosir'],
        provinceId:32
      }
    ];
    public arrayProvinceName:any = [];
    public arrayCityByProvince:any = [];
    public stateVerification:any;
    public mask:any=['+', '6','2', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/ , /\d/];

  constructor(private Camera:Camera, private File:File, private FilePath:FilePath, private FileChooser:FileChooser,private navCtrl: NavController, public userService: UserService, public alertCtrl: AlertController, public modalCtrl:ModalController,  public actionSheetCtrl: ActionSheetController
    , public navParams:NavParams,public toastCtrl: ToastController, public platform: Platform, public loadingCtrl: LoadingController) {
    this.getArrayProvince();
    if(this.navParams.get('stateVerification') == 0){
      this.dataUser = this.navParams.get('dataUser');
      this.email = this.dataUser.email;
      this.stateVerification = this.navParams.get('stateVerification');
    }else{
      this.displayUser();
      this.tutorData();
    }
  }
  getArrayProvince(){
      this.province.forEach(e =>{
        this.arrayProvinceName.push({ id : e.id, text: e.name});
      })
  }

  getProvince(){
    var index = this.dataTutor.provinceId;
    this.arrayCityByProvince = [];
    for (var key in this.city[index].name) {
      var value = this.city[index].name[key];
      this.arrayCityByProvince.push({id:key, text:value})
    }
    this.dataTutor.provinceName=this.arrayProvinceName[index].text;
    // return this.arrayCityByProvince;
  }
  getCity(){
    var index = this.dataTutor.cityId;
    this.dataTutor.cityName=this.arrayCityByProvince[index].text;

    // return this.arrayCityByProvince;
  }
  displayTeacher(uid){
    var that = this;
    this.userService.viewTeacher(uid).once('value').then(snapshot =>{
      var data = snapshot.val();
      that.dataTutor = data;
    })

  }


  displayUser(){
    var myuid = firebase.auth().currentUser.uid;
    var that = this;
    this.userService.viewUser(myuid).once('value').then(snapshot=>  {
      var data= snapshot.val();
      this.email = data.email;
      data.key=snapshot.key;
      this.assignDataUser(data);
    // }).then(check =>{
    //   that.numsky=that.dataUser.phoneNumber;
    //     that.userService.viewUser(that.dataUser.uid).once('value',function(snapshot)  {
    //       var data = snapshot.val();
    //       that.dataTutor = data;
    //     })
    })


  }
  assignDataUser(data){
    this.dataUser=data;
  }

  tutorData(){
    var myuid = firebase.auth().currentUser.uid;
    var that = this;
    that.userService.viewTutorProfile(myuid).once('value').then(snapshotData => {
      that.assignDataTutor(snapshotData.val());
    });
  }
  assignDataTutor(data){
    this.dataTutor=data;
    if(data.provinceId != null || data.provinceId != undefined){
      this.getProvince();
    }
  }
  private createFileName() {
  var d = new Date(),
  n = d.getTime(),
  newFileName =  n + ".jpg";
  return newFileName;
}

  public uploadImage(data,fileType) {
  // Destination URL
  let storageRef = firebase.storage().ref(this.dataUser.key);

  const filename = fileType;
  const imageRef = storageRef.child(`${filename}.png`);

    this.loading = this.loadingCtrl.create({
      content:'<img src="./assets/loading.gif"/>',
      spinner:'hide'
    });
  this.loading.present();
    imageRef.putString(data, 'base64', {contentType:'image/jpg'}).then((snapshot)=> {
      var that=this;
      if(fileType == 'profile'){
        that.dataUser.avatar = snapshot.downloadURL;
        that.presentToast('Foto telah tersimpan');
        that.loading.dismissAll()
      }else{
        that.dataTutor.ktpUrl = snapshot.downloadURL;
        that.presentToast('KTP telah tersimpan');
        that.loading.dismissAll()
      }
    }, err => {
      this.presentToast('Error while uploading file');
    });

}


private presentToast(text) {
  let toast = this.toastCtrl.create({
    message: text,
    duration: 3000,
    position: 'top'
  });
  toast.present();
}

// Always get the accurate path to your apps folder
public pathForImage(img) {
  if (img === null) {
    return '';
  } else {
    return cordova.file.dataDirectory + img;
  }
}
  public takePicture(sourceType, fileType) {
    var that =this;
    // Create options for the Camera Dialog
    if(fileType != 'KTP'){
      let options : CameraOptions = {
        quality: 50,
        sourceType: sourceType,
        saveToPhotoAlbum: true,
        allowEdit : true,
        destinationType: 0,
        encodingType: this.Camera.EncodingType.JPEG,
        mediaType: 0,
        correctOrientation : true
      };
      that.Camera.getPicture(options).then((imagePath) => {
        // Special handling for Android library
          that.uploadImage(imagePath,fileType);
      }, err => {
        that.presentToast(JSON.stringify(err));
      });
    }else{
      let options : CameraOptions = {
        quality: 50,
        sourceType: sourceType,
        saveToPhotoAlbum: true,
        allowEdit : false,
        destinationType: 0,
        encodingType: this.Camera.EncodingType.JPEG,
        mediaType: 0,
        correctOrientation : true
      };
      that.Camera.getPicture(options).then((imagePath) => {
        // Special handling for Android library
          that.uploadImage(imagePath,fileType);
      }, err => {
        that.presentToast(JSON.stringify(err));
      });
    }


    // Get the data of an image

  }


   public presentActionSheet(fileType) {
     let actionSheet = this.actionSheetCtrl.create({
       title: 'Select Image Source',
       buttons: [
         {
           text: 'Load from Library',
           handler: () => {
             this.takePicture(0, fileType);
           }
         },
         {
           text: 'Use Camera',
           handler: () => {
             this.takePicture(1, fileType);
           }
         },
         {
           text: 'Cancel',
           role: 'cancel'
         }
       ]
     });
     actionSheet.present();
   }
  uploadFile(){
    var that = this;
    var extension;
      that.FileChooser.open().
      then(uri => {   if (that.platform.is('android')){
        that.loading = that.loadingCtrl.create({
          content:'<img src="./assets/loading.gif"/>',
          spinner:'hide'
        });
      that.loading.present();
        that.FilePath.resolveNativePath(uri).then((fileentry) => {
          if(fileentry.toString().charAt(fileentry.toString().length - 1) == 'f'){
            extension = '.pdf';
          }else{
            that.loading.dismiss();
            return that.presentToast('File harus menggunakan format .PDF');
          }
          that.makeFileIntoBlob(fileentry).then((fileblob) => {

            that.addFile(fileblob, that.dataUser.key, 'cv', "application/pdf", extension).then(success=>{
               that.dataTutor.cvUrl = success.downloadURL;
              that.loading.dismiss();
            },error=>{
              alert(JSON.stringify(error));
              that.presentToast(error);
              that.loading.dismiss();
            })

                },error =>{
                  alert(JSON.stringify(error));
                  that.presentToast(error);
                  that.loading.dismiss();
                })
          }, error =>{
          alert('File tidak berada di dalam handphone anda, harap download ke dalam storage anda terlebih dahulu');
            that.loading.dismiss();
          })

    }
},error=> {this.presentToast('update versi android anda (min. 4.4.3)')});
   }

   addFile(pdfblob, uid, filename,mimetype, extension):any{
     this.presentToast('CV telah tersimpan');

    return  firebase.storage().ref(uid).child(filename+extension)
             .put(pdfblob,{contentType: mimetype});
       }

   makeFileIntoBlob(_imagePath) {
     var that=this;
// INSTALL PLUGIN - cordova plugin add cordova-plugin-file
  return new Promise((resolve, reject) => {
    that.platform.ready().then(() => {
    window.resolveLocalFileSystemURL(_imagePath, (fileEntry) => {

      fileEntry.file((resFile) => {

    var reader = new FileReader();
    reader.onloadend = (evt: any) => {
      var imgBlob: any = new Blob([evt.target.result], { type: 'application/pdf' });
      imgBlob.name = 'cv.pdf';
      resolve(imgBlob);
    };

    reader.onerror = (e) => {
      that.presentToast('Failed file read: ' + e.toString());
      return reject(e);
    };

    reader.readAsArrayBuffer(resFile);
        });
      });
    });
    });
  }

  openMap(type,val){
      let filterModal = this.modalCtrl.create(MapsPage);
      filterModal.present();
      filterModal.onDidDismiss(data =>{
      this.dataTutor.latitude=data.lat;
      this.dataTutor.longitude=data.lng;
      this.dataTutor.displayAddress = data.address;
    })
  }

  saveProfile(){
    var that=this;
    this.dataTutor.firstName = this.dataUser.firstName;
    this.dataTutor.lastName = this.dataUser.lastName;
    this.dataTutor.gender = this.dataUser.gender;
    this.dataTutor.uid = this.dataUser.key;
    if(that.dataTutor.ktpUrl == undefined){
      return that.presentToast('Harap mengupload KTP');
    }
    if(this.dataTutor.cvUrl == undefined){
      return that.presentToast('Harap mengupload CV');
    }
    if(this.numsky != this.dataUser.phoneNumber){
      that.dataUser.smsVerificationStatus=false;
    }

    // if(that.email != that.dataUser.email){
    //   firebase.auth().currentUser.updateEmail(that.dataUser.email).then(function(success){
    //     that.presentToast('Email anda terupdate : '+that.dataUser.email);
    //   },function(error){
    //     that.presentToast('error update email :'+error);
    //   })
    // }
    that.userService.updateTutorProfile(that.dataUser.key,{namaRekening:that.dataTutor.namaRekening,displayAddress:that.dataTutor.displayAddress,rekening:that.dataTutor.rekening,cabang:that.dataTutor.cabang,
      bank:that.dataTutor.bank,about:that.dataTutor.about,address:that.dataTutor.address,avatar:that.dataUser.avatar,cityId:that.dataTutor.cityId,
      cityName:that.dataTutor.cityName,createDate:firebase.database.ServerValue.TIMESTAMP,cvUrl:that.dataTutor.cvUrl,dob:that.dataTutor.dob
      ,email:that.dataUser.email,firstName:that.dataUser.firstName,fullName:that.dataUser.firstName+' '+that.dataUser.lastName,gender:that.dataUser.gender,
      jurusan:that.dataTutor.jurusan,ktpUrl:that.dataTutor.ktpUrl,lastName:that.dataTutor.lastName,latitude:that.dataTutor.latitude,longitude:that.dataTutor.longitude
      ,pekerjaan:that.dataTutor.pekerjaan,phoneNumber:that.dataUser.phoneNumber,postalCode:that.dataTutor.postalCode,provinceId:that.dataTutor.provinceId,provinceName:that.dataTutor.provinceName
      ,tingkatPendidikanTerakhir:that.dataTutor.tingkatPendidikanTerakhir,universitas:that.dataTutor.universitas,perguruanTinggi:''}).then(success=>{

      }).catch(error =>{
        return that.presentToast(error);
      });
        that.userService.updateTutorUser(that.dataUser.key, {email:that.dataUser.email, gender:that.dataUser.gender,
          firstName:that.dataUser.firstName,lastName:that.dataUser.lastName,phoneNumber:that.dataUser.phoneNumber,
          updateDate:firebase.database.ServerValue.TIMESTAMP,updateBy:that.dataUser.key,
          avatar:that.dataUser.avatar}).then(updated =>{
            if(that.stateVerification <1){
              that.userService.updateTutorUser(that.dataUser.key,{stateVerification:1});
            }
            that.presentToast('Profil Anda telah tersimpan');
            that.navCtrl.pop();
          }).catch(error =>{
            return that.presentToast(error);
          });
    // firebase.database().ref('tutorProfile/'+that.dataUser.key).update().then(success=>{
    //   firebase.database().ref('users/'+that.dataUser.key).update().then(()=>{
    //       if(that.stateVerification <1 ){
    //         firebase.database().ref('users/'+that.dataUser.key).update({stateVerification:1});
    //       }
    //     that.presentToast('Profil Anda telah tersimpan');
    //     that.navCtrl.pop();
    //   },error =>{
    //     that.presentToast('Koneksi terputus');
    //     return that.platform.exitApp();
    //   });
    // },error=>{
    //   that.presentToast('Koneksi terputus');
    //   return that.platform.exitApp();
    // });

  }
  forgetPass(){
    this.userService.forgotUser(this.dataUser.email).then(authData =>  {
      alert("Password telah dikirim ke email anda");
    },error => {
      alert("Email anda tidak terdaftar");
    });
  };
}
